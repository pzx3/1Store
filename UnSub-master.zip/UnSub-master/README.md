# UnSub

Disable Substitute in Electra/Chimera for certain apps.